package GUIDesign;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.event.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Enumeration;


public class Administrator extends User{

	private JFrame frame;
	private JPanel contentPane;
	private JTextField Add_Name;
	private JTextField Modi_Name;
	private JPasswordField Modi_password;
	private JPasswordField Add_password;
	private JPasswordField passwordField;
	private JPasswordField passwordField_1;
	private JPasswordField passwordField_2;
	private JTextField textField;
	public Administrator(String name,String password,String role) {
		super(name,password,role);
	}
	
	/**
	 * @wbp.parser.entryPoint
	 */
	public void showMenu() throws IOException, DataException {
		frame = new JFrame();
		frame.setTitle("����¼��Ա�˵�");
		frame.setBounds((1920 - 1080)/2 ,(1080 - 700)/2,  1080, 700);
		frame.setVisible(true);
		
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		frame.setContentPane(contentPane); 
		
		//���ֲ˵�ѡ��
		JMenuBar menuBar = new JMenuBar();
		frame.setJMenuBar(menuBar);
		
		JMenu FileMenu = new JMenu("�ļ�");
		menuBar.add(FileMenu);
		
		JMenuItem FileList_menuItem = new JMenuItem("�ļ��б�");
		FileMenu.add(FileList_menuItem);
		FileList_menuItem.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
				FileList();
			}
		});
		
		
		JMenuItem DownLoadFile_menuItem = new JMenuItem("�����ļ�");
		FileMenu.add(DownLoadFile_menuItem);
		DownLoadFile_menuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					JFileChooser fileChooser = new JFileChooser(DataProcessing.UPLOAD_PATH);
					//���ļ������ļ����ݱ��浽buffer��
					int result = fileChooser.showOpenDialog(null);
					if(result == JFileChooser.APPROVE_OPTION)
					{
						File file = fileChooser.getSelectedFile();
						if(JOptionPane.OK_OPTION == JOptionPane.showConfirmDialog(null, "�Ƿ�����", "ѯ��", JOptionPane.OK_CANCEL_OPTION))
						{
							File tofr = new File(DataProcessing.DOWNLOAD_PATH + "\\" + file.getName());
							if(!tofr.exists()) {
								tofr.createNewFile(); //����һ����ѡ���ļ�ͬ�������ļ�
								JProgressBar jpb = new JProgressBar(); // ������
								jpb.setPreferredSize(new Dimension(400, 50));
								new Thread(){
									public void run(){
									    int i = 0;
									    while (i < 100){
									        i++;
									        jpb.setValue(i);
									        jpb.setString("���������" + i + "%");
									        jpb.setStringPainted(true);
									        if(i == 100) {
									        	try {
													DataProcessing.copyFile(file, tofr);
													JOptionPane.showMessageDialog(null, "���سɹ�", "֪ͨ", JOptionPane.INFORMATION_MESSAGE);
												} catch (IOException e) {
													e.printStackTrace();
												}
									        }
											      
									        try{
										        Thread.sleep(30);
									        }
									        catch (InterruptedException e1){
										        e1.printStackTrace();
									        }
								        }
							        }
							   }.start(); 
							   JFrame frame = new JFrame("�����ļ�");
							   frame.setLayout(new BorderLayout(5,5));
							   frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
							   frame.setSize(400,100);
							   frame.setVisible(true);
							   frame.setLocationRelativeTo(null);
							   frame.getContentPane().add(jpb,BorderLayout.NORTH);
							}	
							else
								JOptionPane.showMessageDialog(null, "���ļ��Ѿ�����", "����ʧ��", JOptionPane.ERROR_MESSAGE);
						}
					}
				}
				catch (IOException e1) {
					e1.printStackTrace();
				}
			}
		});
		
		JMenuItem uploadfile_MenuItem = new JMenuItem("�ϴ��ļ�");
		uploadfile_MenuItem.setEnabled(false);
		FileMenu.add(uploadfile_MenuItem);
		
		JMenu UserMenu = new JMenu("�û�");
		menuBar.add(UserMenu);
		
		JMenuItem AddUser_menuItem = new JMenuItem("�����û�");
		AddUser_menuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				UserOperate();
			}
		});
		UserMenu.add(AddUser_menuItem);
		
		JMenuItem DelUser_MenuItem = new JMenuItem("ɾ���û�");
		UserMenu.add(DelUser_MenuItem);
		DelUser_MenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {	
				UserDel();
			}
		});
		
		JMenuItem UserList_menuItem = new JMenuItem("�û��б�");
		UserMenu.add(UserList_menuItem);
		UserList_menuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				UserList();
			}
		});
		
		JMenuItem ModiUser_menuItem = new JMenuItem("�޸��û���Ϣ");
		UserMenu.add(ModiUser_menuItem);
		ModiUser_menuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				UserOperate();
			}
		});
		
		JMenuItem ChangeInfo_MenuItem = new JMenuItem("�޸�����");
		UserMenu.add(ChangeInfo_MenuItem);
		ChangeInfo_MenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				UserOperate();
			}			
		});
		
		//���ӹرմ����¼�����
		frame.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				if(JOptionPane.OK_OPTION == JOptionPane.showConfirmDialog(frame, "�Ƿ��˳�","��ʾ",JOptionPane.OK_CANCEL_OPTION))
				    frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
				else
				    frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);	
			}
		});
	}
	
	//���û��Ĳ���
	public void UserOperate() 
	{
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		contentPane.add(tabbedPane, BorderLayout.CENTER);
		
		//���ֹ������
				JPanel panelFileList = new JPanel();
				tabbedPane.addTab("�ļ��б�", panelFileList);
				panelFileList.setLayout(new BorderLayout());
				
				JPanel panelAdd = new JPanel();
				tabbedPane.addTab("�����û�", null, panelAdd, null);
				panelAdd.setLayout(null);
								
				JPanel panelModi = new JPanel();
				tabbedPane.addTab("�޸��û���Ϣ", null, panelModi, null);
				panelModi.setLayout(null);
				
				JPanel Changeinfo_panel = new JPanel();
				tabbedPane.addTab("�޸�����", null, Changeinfo_panel, null);
				Changeinfo_panel.setLayout(null);
       
		//�����û�
		JLabel Add_label_Name = new JLabel("�û���");
		Add_label_Name.setBounds(207, 108, 45, 18);
		panelAdd.add(Add_label_Name);
		
		Add_Name = new JTextField();
		Add_Name.setBounds(290, 105, 166, 24);
		panelAdd.add(Add_Name);
		Add_Name.setColumns(20);
		
		JLabel Add_label_password = new JLabel("����");
		Add_label_password.setBounds(207, 167, 45, 24);
		panelAdd.add(Add_label_password);
		
		Add_password = new JPasswordField();
		Add_password.setBounds(290, 167, 166, 24);
		panelAdd.add(Add_password);
		
		JLabel Add_label_role = new JLabel("����");
		Add_label_role.setBounds(207, 219, 72, 26);
		panelAdd.add(Add_label_role);
		
		JComboBox<Object> Add_role = new JComboBox<Object>();
		Add_role.setModel(new DefaultComboBoxModel<Object>(new String[] {"Operator", "Browser"}));
		Add_role.setBounds(290, 220, 166, 24);
		panelAdd.add(Add_role);
		
		JButton btnNewButton = new JButton("ȷ��");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
		        User user = DataProcessing.searchUser(Add_Name.getText());
		        if(user != null)
		        	JOptionPane.showMessageDialog(null, "���û��Ѵ���", "����ʧ��", JOptionPane.ERROR_MESSAGE);
		        else {
		        	try {
						if(DataProcessing.insertUser(Add_Name.getText(), new String(Add_password.getPassword()), Add_role.getSelectedItem().toString()))
						    JOptionPane.showMessageDialog(null, "���ӳɹ�", "Succeed", JOptionPane.INFORMATION_MESSAGE);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
		        }   	
			}
		});
		btnNewButton.setBounds(207, 316, 249, 27);
		panelAdd.add(btnNewButton);
	
		
		//�޸��û���Ϣ
		JLabel Modi_label_Name = new JLabel("�û���");
		Modi_label_Name.setBounds(235, 116, 72, 18);
		panelModi.add(Modi_label_Name);
		
		Modi_Name = new JTextField();
		Modi_Name.setText("");
		Modi_Name.setBounds(377, 113, 114, 24);
		panelModi.add(Modi_Name);
		Modi_Name.setColumns(10);
		
		JLabel Modi_label_password = new JLabel("������");
		Modi_label_password.setBounds(235, 173, 72, 18);
		panelModi.add(Modi_label_password);
		
		Modi_password = new JPasswordField();
		Modi_password.setBounds(377, 170, 114, 24);
		panelModi.add(Modi_password);
		
		JLabel Modi_label_role = new JLabel("������");
		Modi_label_role.setBounds(235, 237, 72, 18);
		panelModi.add(Modi_label_role);
		
		JComboBox<Object> Modi_role = new JComboBox<Object>();
		Modi_role.setModel(new DefaultComboBoxModel<Object>(new String[] {"Operator", "Browser"}));
		Modi_role.setBounds(377, 234, 114, 24);
		panelModi.add(Modi_role);
		
		JButton Modi_button_OK = new JButton("ȷ��");
		Modi_button_OK.setBounds(235, 322, 256, 27);
		panelModi.add(Modi_button_OK);
		Modi_button_OK.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				User user = DataProcessing.searchUser(Modi_Name.getText());
				if(user == null)
					JOptionPane.showMessageDialog(null, "�����ڸ��û�", "UnSucceed", JOptionPane.ERROR_MESSAGE);
				else {
						try {
							if(DataProcessing.updateUser(Modi_Name.getText(), new String(Modi_password.getPassword()), Modi_role.getSelectedItem().toString()))
								JOptionPane.showMessageDialog(null, "�޸ĳɹ�", "Succeed", JOptionPane.INFORMATION_MESSAGE);
							else
								JOptionPane.showMessageDialog(null, "�޸�ʧ��", "UnSucceed", JOptionPane.INFORMATION_MESSAGE);
						} catch (HeadlessException e1) {
							e1.printStackTrace();
						} catch (Exception e1) {
							e1.printStackTrace();
						}		
				}	
			}
		});	
		
		//�޸�����

		JLabel Label1 = new JLabel("��ǰ�û�");
		Label1.setBounds(239, 113, 72, 18);
		Changeinfo_panel.add(Label1);
		
	    textField = new JTextField();
		textField.setBounds(402, 110, 150, 24);
		Changeinfo_panel.add(textField);
		textField.setColumns(10);
		textField.setText(getName());
		textField.setEditable(false);
		
		JLabel Label2 = new JLabel("�����������");
		Label2.setBounds(239, 162, 91, 32);
		Changeinfo_panel.add(Label2);
		
		passwordField = new JPasswordField();
		passwordField.setColumns(20);
		passwordField.setBounds(402, 166, 150, 24);
		Changeinfo_panel.add(passwordField);
		
		JLabel Label3 = new JLabel("������������");
		Label3.setBounds(239, 219, 91, 18);
		Changeinfo_panel.add(Label3);
		
		passwordField_1 = new JPasswordField();
		passwordField_1.setText("");
		passwordField_1.setBounds(402, 216, 150, 24);
		Changeinfo_panel.add(passwordField_1);
		
		JLabel Label4 = new JLabel("���ٴ�����������");
		Label4.setBounds(239, 276, 120, 18);
		Changeinfo_panel.add(Label4);
		
		passwordField_2 = new JPasswordField();
		passwordField_2.setBounds(402, 273, 150, 24);
		Changeinfo_panel.add(passwordField_2);
		
		JButton btnNewButton_1 = new JButton("\u786E\u8BA4");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String opassword = new String(passwordField.getPassword());
				String newpassword1 = new String(passwordField_1.getPassword());
				String newpassword2 = new String(passwordField_2.getPassword());
				User user = DataProcessing.searchUser(getName(),opassword);
				if(user == null)
					JOptionPane.showMessageDialog(null, "����������", "UnSucceed", JOptionPane.ERROR_MESSAGE);
				else
				    try {
					if(newpassword1.equals(newpassword2)) {
						if(newpassword1.equals(""))
							JOptionPane.showMessageDialog(null, "���벻������Ϊ��", "֪ͨ", JOptionPane.ERROR_MESSAGE);
						else {
							if(newpassword1.equals(opassword))
								JOptionPane.showMessageDialog(null, "�������ԭ����һ��,�����޸�", "֪ͨ", JOptionPane.INFORMATION_MESSAGE);
							else {
								DataProcessing.updateUser(getName(), newpassword1, getRole());
								JOptionPane.showMessageDialog(null, "�޸ĳɹ�", "Succeed", JOptionPane.INFORMATION_MESSAGE);
							}
						}
					}
					else
						JOptionPane.showMessageDialog(null, "�������������벻һ��", "�޸�ʧ��", JOptionPane.ERROR_MESSAGE);		
				} catch (Exception e1) {
						e1.printStackTrace();
				} 
			}
		});
		btnNewButton_1.setBounds(324, 376, 156, 32);
		Changeinfo_panel.add(btnNewButton_1);
	}
	
	//�û��б�
	public void UserList() 
	{
		JFrame frame = new JFrame();
		frame.setVisible(true);
		frame.setLayout(new BorderLayout());
		
		JPanel panelUserList = new JPanel();
		frame.getContentPane().add(panelUserList, BorderLayout.CENTER);
		
		try {
			DataProcessing.Init();
		} catch (IOException e1) {

			e1.printStackTrace();
		} catch (DataException e1) {
			e1.printStackTrace();
		} //�ȳ�ʼ���ļ��������޸���Ϣ��ʱ����
	
        String[] columnNames = {"�û���","����","����"};
        DefaultTableModel tableModel = new DefaultTableModel(columnNames,0){
			private static final long serialVersionUID = 1L;

			public boolean isCellEditable(int row, int column)
            {
                return false;
            }			
		};
        
		Enumeration<User> e = DataProcessing.getAllUser();
		User user;
		while(e.hasMoreElements())
		{
			user = e.nextElement();
			String[] userinfo = {user.getName(),user.getPassword(),user.getRole()};
			tableModel.addRow(userinfo);
		}
		
		JTable table = new JTable(tableModel);
		table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
		table.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
		
		JScrollPane scrollPane = new JScrollPane(table);
		
		panelUserList.add(scrollPane,BorderLayout.CENTER);
		
		frame.pack();
		frame.setLocation((1920 - frame.getWidth())/2,(1080 - frame.getHeight())/2);
		//���ӹرմ����¼�����
		frame.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				if(JOptionPane.OK_OPTION == JOptionPane.showConfirmDialog(frame, "�Ƿ��˳�","��ʾ",JOptionPane.OK_CANCEL_OPTION))
					frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
				else
				    frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);	
			    }
		});
	}
	
	//�ļ��б�
	public void FileList()
	{
		JFrame frame = new JFrame("�ļ��б�");
		frame.setBounds((1920 - 1080)/2 ,(1080 - 700)/2,  1080, 700);
		frame.getContentPane().setLayout(new BorderLayout());
		
		String[] columnNames = {"�ļ����","������","���һ�β���ʱ��","�ļ�����","�ļ���"};
		DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0);
		
		Enumeration<Doc> e = DataProcessing.getAllDocs();
		Doc doc;
		while(e.hasMoreElements())
		{
			doc = e.nextElement();
			long time = doc.getTimestamp();
			SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			String newtime = df.format(time);
			tableModel.addRow(new String[] {doc.getID(),doc.getCreator(),newtime,doc.getDescription(),doc.getFilename()});
		}
		
		JTable table = new JTable(tableModel);
		table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
		table.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
		
		JScrollPane scrollPane = new JScrollPane(table);
		
		frame.getContentPane().add(scrollPane, BorderLayout.CENTER);
		
		
		frame.addWindowListener(new WindowAdapter() {
		    public void windowClosing(WindowEvent e)
			{
				if(JOptionPane.OK_OPTION == JOptionPane.showConfirmDialog(null, "�Ƿ��˳�", "ѯ��", JOptionPane.OK_CANCEL_OPTION))
					frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
				else
					frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
			}
		});
		
		frame.setVisible(true);
	}
	//ɾ���û�
	public void UserDel()
	{
		JFrame frame = new JFrame();
		frame.setVisible(true);
		frame.setLayout(new BorderLayout());
		
		JPanel panelDelUser = new JPanel();
		frame.getContentPane().add(panelDelUser, BorderLayout.CENTER);
		
		try {
			DataProcessing.Init();
		} catch (IOException e1) {

			e1.printStackTrace();
		} catch (DataException e1) {
			e1.printStackTrace();
		} //�ȳ�ʼ���ļ��������޸���Ϣ��ʱ����
	
        String[] columnNames = {"�û���","����","����"};
        DefaultTableModel tableModel = new DefaultTableModel(columnNames,0){
			private static final long serialVersionUID = 1L;

			public boolean isCellEditable(int row, int column)
            {
                return false;
            }			
		};
        
		Enumeration<User> e = DataProcessing.getAllUser();
		User user;
		while(e.hasMoreElements())
		{
			user = e.nextElement();
			String[] userinfo = {user.getName(),user.getPassword(),user.getRole()};
			tableModel.addRow(userinfo);
		}
		
		JTable table = new JTable(tableModel);
		table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
		table.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
		
		JScrollPane scrollPane = new JScrollPane(table);
		
		panelDelUser.add(scrollPane,BorderLayout.CENTER);
		
		JButton Del_Button_OK = new JButton("ȷ��");

		panelDelUser.add(Del_Button_OK,BorderLayout.SOUTH);
		
		Del_Button_OK.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					int row = table.getSelectedRow();
					if(row == -1)
						JOptionPane.showMessageDialog(null, "����ѡ��һ��", "֪ͨ", JOptionPane.ERROR_MESSAGE);
					String name = table.getValueAt(row, 0).toString();
					if(name.equals(getName()))
						JOptionPane.showMessageDialog(null, "�û�����ɾ���Լ�", "֪ͨ", JOptionPane.ERROR_MESSAGE);
					else
					{
						if(DataProcessing.deleteUser(name)) {
							DefaultTableModel tableModel = (DefaultTableModel) table.getModel();
							tableModel.removeRow(row);	// currentRow��Ҫɾ���������
							JOptionPane.showMessageDialog(null, "ɾ���ɹ�", "֪ͨ", JOptionPane.INFORMATION_MESSAGE);	
						}
						else
							JOptionPane.showMessageDialog(null, "ɾ��ʧ��", "֪ͨ", JOptionPane.INFORMATION_MESSAGE);
					}
					
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
		});		
		
		frame.pack();
		frame.setLocation((1920 - frame.getWidth())/2,(1080 - frame.getHeight())/2);
		//���ӹرմ����¼�����
				frame.addWindowListener(new WindowAdapter() {
					public void windowClosing(WindowEvent e) {
						if(JOptionPane.OK_OPTION == JOptionPane.showConfirmDialog(frame, "�Ƿ��˳�","��ʾ",JOptionPane.OK_CANCEL_OPTION))
						    frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
						else
						    frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);	
					}
				});
	}
}